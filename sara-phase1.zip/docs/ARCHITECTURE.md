# SARA — WE LIFT YOU
## Stack (unchanged from your spec)
Flutter (mobile) · Node.js + TypeScript + Express (REST) · PostgreSQL + PostGIS (distance search) · S3-compatible storage (Cloudflare R2) · Next.js admin · FCM · OTP via MSG91/Twilio · Maps: Google Maps (OSM fallback).
Only addition: PostGIS extension for fast "within 30 km" queries. State: Riverpod. Routing: go_router.

## Folders
sara/
  mobile/lib/{core(theme,widgets,l10n,utils), data(models,api,repos), features(auth,home,search,sell,listing,requests,chat,deals,transport,ratings,profile)}
  backend/src/{modules(auth,users,listings,search,requests,chat,offers,deals,transport,ratings,notifications,admin),middleware,db,config}
  admin/ (Next.js)   database/ (schema.sql, migrations, seeds)   docs/

## API (REST /v1)
POST /auth/otp/request · /auth/otp/verify · /auth/refresh
GET/PATCH /me · GET /categories (with attribute definitions)
GET/POST /listings · GET/PATCH/DELETE /listings/:id · POST /listings/:id/media
GET /search?q=&category=&lat=&lng=&radius=&minPrice=&maxPrice=&attrs[...]=&sort=
POST/GET /buyer-requests · GET /buyer-requests/:id/matches
POST /chats · GET /chats · GET/POST /chats/:id/messages (+WebSocket)
POST /offers · POST /offers/:id/{accept|counter|reject}
GET /deals/:id · POST /deals/:id/{transport|complete}
POST /ratings (only if deal.status = completed)
GET /market-guide?category=&attrs=  (comparable listings, never an "exact price")
Admin: /admin/{listings,users,verification,reports,categories,analytics}

## Roadmap
1 Setup/design system/nav/l10n (this drop) → 2 Auth/profile/home → 3 Categories/sell/photos → 4 Search/location/buyer requests → 5 Chat/offers/deal room → 6 Transport/ratings/notifications → 7 Admin → 8 Test/perf/release
