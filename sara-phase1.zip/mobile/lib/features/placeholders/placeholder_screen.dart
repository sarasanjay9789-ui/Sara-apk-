import 'package:flutter/material.dart';
import 'package:sara/core/l10n/app_localizations.dart';
import '../../core/widgets/empty_state.dart';

enum PlaceholderKind { search, sell, chat, profile }

class PlaceholderScreen extends StatelessWidget {
  final PlaceholderKind kind;
  const PlaceholderScreen({super.key, required this.kind});
  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final (title, icon, msg) = switch (kind) {
      PlaceholderKind.search => (t.search, Icons.search, t.coming_soon),
      PlaceholderKind.sell => (t.sell_product, Icons.add_circle_outline, t.coming_soon),
      PlaceholderKind.chat => (t.chat, Icons.chat_bubble_outline, t.no_messages),
      PlaceholderKind.profile => (t.profile, Icons.person_outline, t.coming_soon),
    };
    return Scaffold(
        appBar: AppBar(title: Text(title)),
        body: EmptyState(icon: icon, message: msg));
  }
}
