import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:sara/core/l10n/app_localizations.dart';
import '../../core/l10n/locale_provider.dart';
import '../../core/theme/sara_theme.dart';
import '../../core/widgets/empty_state.dart';
import '../../core/widgets/sara_button.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = AppLocalizations.of(context)!;
    final isTamil = ref.watch(localeProvider).languageCode == 'ta';
    final cats = <(IconData, String)>[
      (Icons.pets, t.cat_cattle), (Icons.cruelty_free, t.cat_goat), (Icons.grass, t.cat_sheep),
      (Icons.egg_alt, t.cat_poultry), (Icons.set_meal, t.cat_fish), (Icons.agriculture, t.cat_crops),
      (Icons.inventory_2, t.cat_feed), (Icons.precision_manufacturing, t.cat_machinery), (Icons.handyman, t.cat_services),
    ];
    return Scaffold(
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(SaraSpacing.md), children: [
          Center(
            child: Image.asset('assets/images/sara_logo.png',
                width: MediaQuery.of(context).size.width * .62,
                cacheWidth: 600, semanticLabel: 'SARA - WE LIFT YOU'),
          ),
          const SizedBox(height: SaraSpacing.sm),
          Row(children: [
            const Icon(Icons.location_on_outlined, color: SaraColors.green),
            const Expanded(child: Text(' Attur', overflow: TextOverflow.ellipsis)),
            IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
            TextButton(
              onPressed: () => ref.read(localeProvider.notifier).state = Locale(isTamil ? 'en' : 'ta'),
              child: Text(isTamil ? 'EN' : 'தமிழ்'),
            ),
          ]),
          const SizedBox(height: SaraSpacing.md),
          TextField(
              decoration: InputDecoration(
                  hintText: t.search_hint,
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(SaraSpacing.radius),
                      borderSide: BorderSide.none))),
          const SizedBox(height: SaraSpacing.md),
          GridView.count(
            crossAxisCount: 3, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: .95,
            children: [for (final c in cats) _CategoryTile(icon: c.$1, label: c.$2)],
          ),
          const SizedBox(height: SaraSpacing.lg),
          SaraButton(label: t.sell_product, icon: Icons.add_circle, onPressed: () {}),
          const SizedBox(height: SaraSpacing.sm),
          SaraButton(label: t.i_want_to_buy, icon: Icons.shopping_basket_outlined, secondary: true, onPressed: () {}),
          const SizedBox(height: SaraSpacing.lg),
          Text(t.nearby_products, style: Theme.of(context).textTheme.titleMedium),
          SizedBox(height: 220, child: EmptyState(icon: Icons.storefront_outlined, message: t.no_products)),
        ]),
      ),
    );
  }
}

class _CategoryTile extends StatelessWidget {
  final IconData icon;
  final String label;
  const _CategoryTile({required this.icon, required this.label});
  @override
  Widget build(BuildContext context) => Card(
        child: InkWell(
            borderRadius: BorderRadius.circular(SaraSpacing.radius),
            onTap: () {},
            child: Padding(
                padding: const EdgeInsets.all(8),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(icon, size: 34, color: SaraColors.green),
                  const SizedBox(height: 6),
                  Text(label,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                ]))),
      );
}
