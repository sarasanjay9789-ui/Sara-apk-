import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:sara/core/l10n/app_localizations.dart';
import 'core/l10n/locale_provider.dart';
import 'core/theme/sara_theme.dart';
import 'features/home/home_screen.dart';
import 'features/placeholders/placeholder_screen.dart';
import 'features/shell/app_shell.dart';

void main() => runApp(const ProviderScope(child: SaraApp()));

StatefulShellBranch _branch(String path, Widget screen) => StatefulShellBranch(
    routes: [GoRoute(path: path, builder: (c, s) => screen)]);

final _router = GoRouter(routes: [
  StatefulShellRoute.indexedStack(
    builder: (c, s, shell) => AppShell(shell: shell),
    branches: [
      _branch('/', const HomeScreen()),
      _branch('/search', const PlaceholderScreen(kind: PlaceholderKind.search)),
      _branch('/sell', const PlaceholderScreen(kind: PlaceholderKind.sell)),
      _branch('/chat', const PlaceholderScreen(kind: PlaceholderKind.chat)),
      _branch('/profile', const PlaceholderScreen(kind: PlaceholderKind.profile)),
    ],
  ),
]);

class SaraApp extends ConsumerWidget {
  const SaraApp({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) => MaterialApp.router(
        title: 'SARA',
        debugShowCheckedModeBanner: false,
        theme: buildSaraTheme(),
        locale: ref.watch(localeProvider),
        supportedLocales: AppLocalizations.supportedLocales,
        localizationsDelegates: const [
          AppLocalizations.delegate,
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        routerConfig: _router,
      );
}
