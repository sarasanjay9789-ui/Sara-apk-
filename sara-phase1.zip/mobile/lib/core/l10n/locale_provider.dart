import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Default Tamil; persisted storage comes in Phase 2.
final localeProvider = StateProvider<Locale>((ref) => const Locale('ta'));
