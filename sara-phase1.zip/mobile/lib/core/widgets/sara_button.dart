import 'package:flutter/material.dart';
import '../theme/sara_theme.dart';

/// Large, farmer-friendly button. Grows with long Tamil labels.
class SaraButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final bool secondary;
  const SaraButton(
      {super.key, required this.label, this.icon, this.onPressed, this.secondary = false});

  @override
  Widget build(BuildContext context) {
    final bg = secondary ? Colors.white : SaraColors.green;
    final fg = secondary ? SaraColors.green : Colors.white;
    return SizedBox(
      width: double.infinity,
      child: ConstrainedBox(
        constraints: const BoxConstraints(minHeight: 56),
        child: FilledButton(
          onPressed: onPressed,
          style: FilledButton.styleFrom(
            backgroundColor: bg,
            foregroundColor: fg,
            side: secondary ? const BorderSide(color: SaraColors.green, width: 2) : null,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(SaraSpacing.radius)),
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            if (icon != null) ...[Icon(icon), const SizedBox(width: 10)],
            Flexible(
                child: Text(label,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700))),
          ]),
        ),
      ),
    );
  }
}
