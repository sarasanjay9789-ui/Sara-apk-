import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SaraColors {
  static const green = Color(0xFF4E6E13); // from SARA logo
  static const gold = Color(0xFFD9A62E);
  static const brown = Color(0xFF7B4E0E); // from SARA logo
  static const brick = Color(0xFFB2402F);
  static const background = Color(0xFFEDF1E1);
  static const ink = Color(0xFF1E2A1F);
}

class SaraSpacing {
  static const xs = 4.0, sm = 8.0, md = 16.0, lg = 24.0, xl = 32.0;
  static const radius = 16.0;
}

ThemeData buildSaraTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: SaraColors.green,
    primary: SaraColors.green,
    secondary: SaraColors.gold,
    error: SaraColors.brick,
    surface: Colors.white,
  );
  final text = GoogleFonts.interTextTheme().apply(bodyColor: SaraColors.ink);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: SaraColors.background,
    textTheme: text.copyWith(
      titleLarge: GoogleFonts.poppins(fontSize: 22, fontWeight: FontWeight.w700),
      bodyLarge: text.bodyLarge?.copyWith(fontSize: 17),
    ),
    navigationBarTheme: NavigationBarThemeData(
      height: 72,
      backgroundColor: Colors.white,
      indicatorColor: SaraColors.gold.withOpacity(.35),
      labelTextStyle: WidgetStatePropertyAll(
          GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w600)),
    ),
  );
}
