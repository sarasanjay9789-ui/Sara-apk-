# SARA — Phase 1
cd mobile
flutter create . --platforms=android,ios   # adds android/ios folders, keeps lib/
flutter pub get
flutter gen-l10n
flutter run
Logo is already in mobile/assets/images (sara_logo.png = 900px in-app copy, sara_logo_original.png = untouched master).
Database: psql -f database/schema.sql (needs PostgreSQL + PostGIS).
